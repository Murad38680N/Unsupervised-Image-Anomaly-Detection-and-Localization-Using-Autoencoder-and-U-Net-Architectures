#!/usr/bin/env python3
"""
app.py — Gradio interactive demo for the Agentic Visual Inspection pipeline.

Loads a trained checkpoint and launches a web UI showing:
  predicted mask, mask×image, pixel boundary, AE error heatmap,
  U-Net probability map, Grad-CAM, and a 3D anomaly-error surface.

Usage:
    python app.py                            # default checkpoint
    python app.py --checkpoint path/to.pt    # custom checkpoint
    python app.py --share                    # create a public link
"""
import argparse
import io
import numpy as np
from PIL import Image
from scipy import ndimage

import torch
import matplotlib
matplotlib.use("Agg")  # non-interactive backend
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

import gradio as gr

from config import IMG_SIZE, CHECKPOINT_PATH, CATEGORY
from models import ConvAutoencoder, UNet, build_feature_extractor
from utils.scoring import combined_anomaly_score
from utils.gradcam import compute_gradcam_unet
from utils.visualization import render_fig_to_array


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", default=CHECKPOINT_PATH)
    parser.add_argument("--share", action="store_true")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    # ── Load checkpoint ──────────────────────────────────────────────────
    ckpt = torch.load(args.checkpoint, map_location=device)
    autoencoder = ConvAutoencoder().to(device).eval()
    autoencoder.load_state_dict(ckpt["autoencoder_state_dict"])

    unet = UNet().to(device).eval()
    unet.load_state_dict(ckpt["unet_state_dict"])

    ae_threshold = ckpt["ae_threshold"]
    norm_stats = ckpt["norm_stats"]
    feat_bank_mean = ckpt["feat_bank_mean"].to(device)
    feat_bank_std = ckpt["feat_bank_std"].to(device)
    feature_extractor = build_feature_extractor(device)
    print(f"Loaded checkpoint. AE threshold = {ae_threshold:.6f}")

    def score_fn(imgs, recon):
        return combined_anomaly_score(
            imgs, recon, feature_extractor, device,
            feat_bank_mean, feat_bank_std, norm_stats,
        )

    # ── Gradio handler ───────────────────────────────────────────────────
    def gradio_inspect(uploaded_image):
        img = Image.fromarray(uploaded_image).convert("RGB").resize((IMG_SIZE, IMG_SIZE))
        img_np = np.asarray(img, dtype=np.float32) / 255.0
        x = torch.from_numpy(img_np).permute(2, 0, 1).unsqueeze(0).float().to(device)

        with torch.no_grad():
            recon = autoencoder(x)
            error_map = (recon - x).abs().mean(dim=1, keepdim=True)
            seg = unet(x)
            score = score_fn(x, recon).item()

        is_anom = score > ae_threshold
        err_np = error_map.squeeze().cpu().numpy()
        seg_np = seg.squeeze().cpu().numpy()
        pred_bin = (
            (seg_np > 0.5).astype(np.float32) if is_anom
            else np.zeros((IMG_SIZE, IMG_SIZE), dtype=np.float32)
        )
        area_pct = float(pred_bin.mean() * 100)

        masked_highlight = img_np * pred_bin[..., None]
        eroded = ndimage.binary_erosion(pred_bin.astype(bool))
        boundary = pred_bin.astype(bool) & (~eroded)
        boundary_overlay = img_np.copy()
        boundary_overlay[boundary] = [1.0, 0.0, 0.0]
        heat_overlay = (
            img_np * 0.5
            + plt.cm.inferno(err_np / (err_np.max() + 1e-8))[..., :3] * 0.5
        )
        cam = compute_gradcam_unet(unet, x)
        cam_overlay = img_np * 0.5 + plt.cm.jet(cam)[..., :3] * 0.5

        panels = [
            (img_np, "Input", None),
            (pred_bin, "Predicted mask", "gray"),
            (masked_highlight, "Mask × Image", None),
            (boundary_overlay, "Pixel boundary", None),
            (heat_overlay, "AE error heatmap", None),
            (seg_np, "U-Net prob. map", "inferno"),
            (cam_overlay, "Grad-CAM", None),
        ]
        fig1, axes = plt.subplots(2, 4, figsize=(16, 8))
        for ax, (im, title, cmap) in zip(axes.flat, panels):
            ax.imshow(im, cmap=cmap); ax.set_title(title, fontsize=11); ax.axis("off")
        for ax in axes.flat[len(panels):]:
            ax.axis("off")
        analysis_img = render_fig_to_array(fig1)

        fig2 = plt.figure(figsize=(6, 5))
        ax3d = fig2.add_subplot(111, projection="3d")
        H, W = err_np.shape
        X, Y = np.meshgrid(np.arange(W), np.arange(H))
        ax3d.plot_surface(X, Y, err_np, cmap="inferno", linewidth=0, antialiased=True)
        ax3d.set_title("3D anomaly-error surface")
        ax3d.set_xlabel("x"); ax3d.set_ylabel("y"); ax3d.set_zlabel("error")
        surface_img = render_fig_to_array(fig2)

        action = (
            "PASS" if not is_anom
            else ("REJECT - defect localized" if area_pct > 0.1 else "REVIEW - borderline")
        )
        verdict = (
            f"### Verdict: {action}\n"
            f"- Anomaly score: {score:.5f}  (threshold: {ae_threshold:.5f})\n"
            f"- Flagged: {is_anom}\n"
            f"- Defect area: {area_pct:.2f}% of image\n"
        )
        return analysis_img, surface_img, verdict

    # ── Launch ───────────────────────────────────────────────────────────
    demo = gr.Interface(
        fn=gradio_inspect,
        inputs=gr.Image(label="Part image"),
        outputs=[
            gr.Image(label="Full visual analysis"),
            gr.Image(label="3D anomaly-error surface"),
            gr.Markdown(label="Agent decision"),
        ],
        title="Agentic Visual Inspection",
        description=(
            f"Category: {CATEGORY}. Upload a part image to see the predicted mask, "
            f"affected-region highlight, boundary, heatmap, U-Net probability map, "
            f"Grad-CAM, and 3D error surface."
        ),
    )
    try:
        demo.launch(share=args.share)
    except Exception as e:
        print(f"Could not create share link ({e}). Launching locally.")
        demo.launch(share=False)


if __name__ == "__main__":
    main()
