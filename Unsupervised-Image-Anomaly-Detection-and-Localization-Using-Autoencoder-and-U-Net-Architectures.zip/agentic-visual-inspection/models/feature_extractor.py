"""
ImageNet-pretrained ResNet-18 feature extractor (frozen, early layers only).
Used for perceptual loss during AE training and for feature-bank scoring.
"""
import torch
import torch.nn as nn
import torchvision.models as tv_models

IMAGENET_MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1)
IMAGENET_STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


def build_feature_extractor(device: torch.device) -> nn.Module:
    """Return a frozen early-layer ResNet-18 feature extractor."""
    try:
        weights = tv_models.ResNet18_Weights.IMAGENET1K_V1
        backbone = tv_models.resnet18(weights=weights)
        print("Loaded pretrained ImageNet ResNet-18 weights.")
    except Exception:
        print(
            "Could not download pretrained ResNet-18 weights. "
            "Falling back to random-initialized weights."
        )
        backbone = tv_models.resnet18(weights=None)

    # Keep only conv1 → layer2: good texture semantics, decent spatial resolution
    extractor = nn.Sequential(*list(backbone.children())[:6]).to(device).eval()
    for p in extractor.parameters():
        p.requires_grad_(False)
    return extractor


def extract_features(
    x: torch.Tensor,
    extractor: nn.Module,
    device: torch.device,
) -> torch.Tensor:
    """x: (B, 3, H, W) in [0, 1] → ImageNet-normalised ResNet-18 mid-level features."""
    mean = IMAGENET_MEAN.to(device)
    std = IMAGENET_STD.to(device)
    x_norm = (x - mean) / std
    return extractor(x_norm)
