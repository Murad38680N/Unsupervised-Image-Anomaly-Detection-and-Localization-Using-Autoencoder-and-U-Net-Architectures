#!/usr/bin/env python3
"""
evaluate.py — Run the full evaluation suite on the held-out test slice.

Produces:
  - Autoencoder classification report, confusion matrix, ROC/AUROC
  - U-Net pixel-level confusion matrix, ROC/AUROC
  - Agent classification report, confusion matrix, ROC/AUROC
  - Per-image quantitative CSV (precision / recall / F1 / IoU / Dice)
  - Leave-one-defect-type-out generalization check

Usage:
    python evaluate.py                            # uses default checkpoint
    python evaluate.py --checkpoint path/to.pt    # custom checkpoint
"""
import os
import argparse
import random
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Subset
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_curve, auc, roc_auc_score,
)

from config import SEED, BATCH_SIZE, CHECKPOINT_PATH, REPORT_CSV_PATH, find_category_root
from data import TestDataset, split_test_samples
from models import ConvAutoencoder, UNet, build_feature_extractor
from models.feature_extractor import extract_features
from utils.scoring import combined_anomaly_score
from utils.metrics import (
    find_best_threshold, pixel_metrics, collect_pixel_labels,
    collect_pixel_scores, score_dataset_ae,
)
from utils.visualization import plot_confusion, plot_roc
from agent import VisualInspectionAgent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", default=CHECKPOINT_PATH)
    args = parser.parse_args()

    random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    # ── Load checkpoint ──────────────────────────────────────────────────
    ckpt = torch.load(args.checkpoint, map_location=device)
    autoencoder = ConvAutoencoder().to(device)
    autoencoder.load_state_dict(ckpt["autoencoder_state_dict"])
    autoencoder.eval()

    unet = UNet().to(device)
    unet.load_state_dict(ckpt["unet_state_dict"])
    unet.eval()

    ae_threshold = ckpt["ae_threshold"]
    norm_stats = ckpt["norm_stats"]
    feat_bank_mean = ckpt["feat_bank_mean"].to(device)
    feat_bank_std = ckpt["feat_bank_std"].to(device)
    feature_extractor = build_feature_extractor(device)
    print(f"Checkpoint loaded from {args.checkpoint}")
    print(f"AE threshold: {ae_threshold:.6f}")

    def score_fn(imgs, recon):
        return combined_anomaly_score(
            imgs, recon, feature_extractor, device,
            feat_bank_mean, feat_bank_std, norm_stats,
        )

    # ── Data ─────────────────────────────────────────────────────────────
    root = find_category_root()
    test_ds = TestDataset(root)
    val_indices, final_indices = split_test_samples(test_ds)
    val_subset = Subset(test_ds, val_indices)
    final_subset = Subset(test_ds, final_indices)
    print(f"Held-out test slice: {len(final_subset)} images")

    # ── 1. Autoencoder ───────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("AUTOENCODER — held-out test")
    print("=" * 60)
    ae_scores, ae_labels = score_dataset_ae(final_subset, autoencoder, score_fn, device)
    ae_preds = (ae_scores > ae_threshold).astype(int)
    print(classification_report(ae_labels, ae_preds,
                                target_names=["normal", "defect"], zero_division=0))
    cm_ae = confusion_matrix(ae_labels, ae_preds)
    plot_confusion(cm_ae, "Autoencoder — Confusion Matrix (held-out)")
    fpr_ae, tpr_ae, _ = roc_curve(ae_labels, ae_scores)
    auroc_ae = auc(fpr_ae, tpr_ae)
    print(f"AUROC: {auroc_ae:.3f}")
    plot_roc(fpr_ae, tpr_ae, auroc_ae, "Autoencoder — ROC (held-out)")

    # ── 2. U-Net pixel-level ─────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("U-NET — pixel-level held-out test")
    print("=" * 60)
    pix_true, pix_pred = collect_pixel_labels(final_subset, unet, device)
    print(classification_report(pix_true, pix_pred,
                                target_names=["background", "defect"], zero_division=0))
    cm_px = confusion_matrix(pix_true, pix_pred)
    plot_confusion(cm_px, "U-Net — Pixel Confusion Matrix", labels=("bg", "defect"))
    pix_true_c, pix_scores_c = collect_pixel_scores(final_subset, unet, device)
    fpr_px, tpr_px, _ = roc_curve(pix_true_c, pix_scores_c)
    auroc_px = auc(fpr_px, tpr_px)
    print(f"Pixel AUROC: {auroc_px:.3f}")
    plot_roc(fpr_px, tpr_px, auroc_px, "U-Net — Pixel ROC (held-out)")

    # ── 3. Agent ─────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("AGENT — held-out test")
    print("=" * 60)
    agent = VisualInspectionAgent(autoencoder, unet, ae_threshold, device, score_fn)

    agent_true, agent_scores = [], []
    records = []
    for img_t, mask_t, label, path in DataLoader(final_subset, batch_size=1):
        img_np = img_t.squeeze(0).permute(1, 2, 0).numpy()
        gt_np = mask_t.squeeze().numpy()
        result = agent.inspect(img_np, part_id=os.path.basename(path[0]))
        agent_true.append(label.item())
        agent_scores.append(result["anomaly_score"])
        if label.item() == 1:
            pred_mask = (
                result["defect_mask"] if result["defect_mask"] is not None
                else np.zeros_like(gt_np)
            )
            m = pixel_metrics(pred_mask, gt_np)
            m.update({
                "part_id": os.path.basename(path[0]),
                "anomaly_score": result["anomaly_score"],
                "flagged": result["flagged"],
                "action": result["action"],
                "gt_area_pct": float(gt_np.mean() * 100),
                "pred_area_pct": result["defect_area_pct"],
            })
            records.append(m)

    agent_auroc = roc_auc_score(agent_true, agent_scores)
    agent_preds = (np.array(agent_scores) > ae_threshold).astype(int)
    print(classification_report(np.array(agent_true), agent_preds,
                                target_names=["normal", "defect"], zero_division=0))
    cm_ag = confusion_matrix(agent_true, agent_preds)
    plot_confusion(cm_ag, "Agent — Confusion Matrix (held-out)")
    fpr_ag, tpr_ag, _ = roc_curve(agent_true, agent_scores)
    print(f"Agent AUROC: {agent_auroc:.3f}")
    plot_roc(fpr_ag, tpr_ag, agent_auroc, "Agent — ROC (held-out)")

    # Per-image CSV
    quant_df = pd.DataFrame(records)
    os.makedirs(os.path.dirname(REPORT_CSV_PATH), exist_ok=True)
    quant_df.to_csv(REPORT_CSV_PATH, index=False)
    print(f"\nPer-image report → {REPORT_CSV_PATH}")
    print(quant_df[["precision", "recall", "f1", "iou", "dice"]].describe())

    # ── 4. Leave-one-type-out ────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("GENERALIZATION CHECK — leave-one-defect-type-out")
    print("=" * 60)
    all_defect_types = sorted(set(
        os.path.basename(os.path.dirname(p)) for p, m, l in test_ds.samples if l == 1
    ))
    for hold_type in all_defect_types:
        val_excl = [
            i for i in val_indices
            if not (test_ds.samples[i][2] == 1
                    and os.path.basename(os.path.dirname(test_ds.samples[i][0])) == hold_type)
        ]
        val_sub_excl = Subset(test_ds, val_excl)
        sc, lb = score_dataset_ae(val_sub_excl, autoencoder, score_fn, device)
        thr, _ = find_best_threshold(sc, lb)
        ho_idx = [
            i for i, (p, m, l) in enumerate(test_ds.samples)
            if l == 1 and os.path.basename(os.path.dirname(p)) == hold_type
        ]
        ho_sub = Subset(test_ds, ho_idx)
        ho_sc, ho_lb = score_dataset_ae(ho_sub, autoencoder, score_fn, device)
        det_pct = 100 * (ho_sc > thr).mean()
        print(f"  '{hold_type}': {det_pct:.1f}% detected ({len(ho_idx)} images)")

    print("\nEvaluation complete.")


if __name__ == "__main__":
    main()
