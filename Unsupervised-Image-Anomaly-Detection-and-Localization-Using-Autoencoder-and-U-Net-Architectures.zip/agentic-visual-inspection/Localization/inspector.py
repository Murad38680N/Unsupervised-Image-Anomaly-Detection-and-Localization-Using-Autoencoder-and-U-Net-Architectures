"""
Agentic Visual Inspection:
  1. AE-based anomaly gating (combined pixel + feature + bank score)
  2. If flagged → U-Net pixel-level defect localisation
  3. Decision: PASS / REVIEW / REJECT
"""
import numpy as np
import torch


class VisualInspectionAgent:
    def __init__(self, autoencoder, unet, threshold, device, combined_score_fn):
        self.ae = autoencoder.eval()
        self.unet = unet.eval()
        self.threshold = threshold
        self.device = device
        self.combined_score_fn = combined_score_fn
        self.log = []

    def _to_tensor(self, img_np):
        return (
            torch.from_numpy(img_np)
            .permute(2, 0, 1)
            .unsqueeze(0)
            .float()
            .to(self.device)
        )

    @torch.no_grad()
    def inspect(self, img_np, part_id="part"):
        x = self._to_tensor(img_np)
        recon = self.ae(x)
        score = self.combined_score_fn(x, recon).item()
        is_anomalous = score > self.threshold

        result = {
            "part_id": part_id,
            "anomaly_score": score,
            "threshold": self.threshold,
            "flagged": is_anomalous,
            "defect_mask": None,
            "defect_area_pct": 0.0,
            "action": "PASS",
        }

        if is_anomalous:
            seg = self.unet(x)
            mask = (seg > 0.5).float()
            area_pct = mask.mean().item() * 100
            result.update(
                {
                    "defect_mask": seg.squeeze().cpu().numpy(),
                    "defect_area_pct": area_pct,
                    "action": (
                        "REJECT - defect localized"
                        if area_pct > 0.1
                        else "REVIEW - borderline"
                    ),
                }
            )

        self.log.append({k: v for k, v in result.items() if k != "defect_mask"})
        return result

    def report(self):
        n = len(self.log)
        flagged = sum(1 for r in self.log if r["flagged"])
        print(f"Inspected {n} parts | Flagged {flagged} | Passed {n - flagged}")
        return self.log
