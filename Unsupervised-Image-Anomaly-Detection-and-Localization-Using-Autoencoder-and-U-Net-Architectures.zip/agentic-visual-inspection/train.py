#!/usr/bin/env python3
"""
train.py — Train the full Agentic Visual Inspection pipeline from scratch.

Usage (Kaggle or local):
    python train.py

Outputs:
    outputs/agentic_vision_checkpoint.pt — all weights, thresholds, loss curves
"""
import os
import random
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset, random_split
import matplotlib.pyplot as plt

from config import (
    CATEGORY, IMG_SIZE, BATCH_SIZE, AE_EPOCHS, UNET_EPOCHS, LR, SEED,
    CHECKPOINT_PATH, find_category_root,
)
from data import (
    NormalImagesDataset, TestDataset, RealMaskDataset, GoodOnlyWrapper,
    split_test_samples,
)
from models import ConvAutoencoder, UNet, build_feature_extractor, extract_features
from utils.scoring import (
    build_feature_bank, calibrate_normalization, combined_anomaly_score,
)
from utils.metrics import find_best_threshold, score_dataset_ae


def main():
    # ── Seed ─────────────────────────────────────────────────────────────
    random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # ── Data ─────────────────────────────────────────────────────────────
    root = find_category_root()
    print(f"Dataset root: {root}")

    train_ds = NormalImagesDataset(root)
    test_ds = TestDataset(root)
    val_indices, final_indices = split_test_samples(test_ds)
    val_subset = Subset(test_ds, val_indices)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True,
                              num_workers=2, drop_last=True)

    ae_val_ds = GoodOnlyWrapper(test_ds, val_indices)
    ae_val_loader = DataLoader(ae_val_ds, batch_size=BATCH_SIZE, shuffle=False,
                               num_workers=2)

    unet_full_train_ds = RealMaskDataset(test_ds, val_indices, augment=True, repeats=8)
    n_val_u = max(1, int(0.15 * len(unet_full_train_ds)))
    n_train_u = len(unet_full_train_ds) - n_val_u
    unet_train_split, unet_val_split = random_split(
        unet_full_train_ds, [n_train_u, n_val_u],
        generator=torch.Generator().manual_seed(SEED),
    )
    unet_train_loader = DataLoader(unet_train_split, batch_size=BATCH_SIZE,
                                   shuffle=True, num_workers=2, drop_last=True)
    unet_val_loader = DataLoader(unet_val_split, batch_size=BATCH_SIZE,
                                 shuffle=False, num_workers=2)

    print(f"Train (normal): {len(train_ds)} | Val slice: {len(val_subset)} | "
          f"Held-out: {len(final_indices)}")
    print(f"U-Net: {len(unet_train_split)} train / {len(unet_val_split)} val")

    # ── Feature extractor ────────────────────────────────────────────────
    feature_extractor = build_feature_extractor(device)

    # ── Train Autoencoder ────────────────────────────────────────────────
    autoencoder = ConvAutoencoder().to(device)
    opt_ae = torch.optim.Adam(autoencoder.parameters(), lr=LR)

    ae_train_losses, ae_val_losses = [], []
    for epoch in range(AE_EPOCHS):
        autoencoder.train()
        train_loss = 0.0
        for imgs in train_loader:
            imgs = imgs.to(device)
            recon = autoencoder(imgs)
            pixel_loss = 0.5 * F.mse_loss(recon, imgs) + 0.5 * F.l1_loss(recon, imgs)
            perceptual_loss = F.mse_loss(
                extract_features(recon, feature_extractor, device),
                extract_features(imgs, feature_extractor, device),
            )
            loss = pixel_loss + 0.3 * perceptual_loss
            opt_ae.zero_grad(); loss.backward(); opt_ae.step()
            train_loss += loss.item()
        train_loss /= len(train_loader)

        autoencoder.eval()
        val_loss = 0.0
        with torch.no_grad():
            for imgs in ae_val_loader:
                imgs = imgs.to(device)
                recon = autoencoder(imgs)
                pixel_loss = 0.5 * F.mse_loss(recon, imgs) + 0.5 * F.l1_loss(recon, imgs)
                perceptual_loss = F.mse_loss(
                    extract_features(recon, feature_extractor, device),
                    extract_features(imgs, feature_extractor, device),
                )
                loss = pixel_loss + 0.3 * perceptual_loss
                val_loss += loss.item()
        val_loss /= max(1, len(ae_val_loader))
        ae_train_losses.append(train_loss)
        ae_val_losses.append(val_loss)
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"[AE] epoch {epoch+1}/{AE_EPOCHS}  "
                  f"train={train_loss:.5f}  val={val_loss:.5f}")

    # ── Feature bank + normalization ─────────────────────────────────────
    feat_bank_mean, feat_bank_std = build_feature_bank(
        train_loader, feature_extractor, device
    )
    norm_stats = calibrate_normalization(
        ae_val_loader, autoencoder, feature_extractor, device,
        feat_bank_mean, feat_bank_std,
    )

    # Helper with all dependencies baked in
    def score_fn(imgs, recon):
        return combined_anomaly_score(
            imgs, recon, feature_extractor, device,
            feat_bank_mean, feat_bank_std, norm_stats,
        )

    # ── AE threshold ─────────────────────────────────────────────────────
    ae_val_scores, ae_val_labels = score_dataset_ae(
        val_subset, autoencoder, score_fn, device
    )
    ae_threshold, ae_val_j = find_best_threshold(ae_val_scores, ae_val_labels)
    print(f"AE threshold = {ae_threshold:.6f}  (Youden's J = {ae_val_j:.3f})")

    # ── Train U-Net ──────────────────────────────────────────────────────
    unet = UNet().to(device)
    opt_unet = torch.optim.Adam(unet.parameters(), lr=LR)

    def dice_loss(pred, target, eps=1e-6):
        pred = pred.reshape(pred.size(0), -1)
        target = target.reshape(target.size(0), -1)
        inter = (pred * target).sum(dim=1)
        union = pred.sum(dim=1) + target.sum(dim=1)
        return 1 - ((2 * inter + eps) / (union + eps)).mean()

    unet_train_losses, unet_val_losses = [], []
    for epoch in range(UNET_EPOCHS):
        unet.train()
        train_loss = 0.0
        for imgs, masks in unet_train_loader:
            imgs, masks = imgs.to(device), masks.to(device)
            preds = unet(imgs)
            loss = F.binary_cross_entropy(preds, masks) + dice_loss(preds, masks)
            opt_unet.zero_grad(); loss.backward(); opt_unet.step()
            train_loss += loss.item()
        train_loss /= len(unet_train_loader)

        unet.eval()
        val_loss = 0.0
        with torch.no_grad():
            for imgs, masks in unet_val_loader:
                imgs, masks = imgs.to(device), masks.to(device)
                preds = unet(imgs)
                loss = F.binary_cross_entropy(preds, masks) + dice_loss(preds, masks)
                val_loss += loss.item()
        val_loss /= max(1, len(unet_val_loader))
        unet_train_losses.append(train_loss)
        unet_val_losses.append(val_loss)
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"[U-Net] epoch {epoch+1}/{UNET_EPOCHS}  "
                  f"train={train_loss:.5f}  val={val_loss:.5f}")

    # ── Save checkpoint ──────────────────────────────────────────────────
    os.makedirs(os.path.dirname(CHECKPOINT_PATH), exist_ok=True)
    checkpoint = {
        "autoencoder_state_dict": autoencoder.state_dict(),
        "unet_state_dict": unet.state_dict(),
        "ae_threshold": ae_threshold,
        "unet_pixel_threshold": 0.5,
        "norm_stats": norm_stats,
        "feat_bank_mean": feat_bank_mean.cpu(),
        "feat_bank_std": feat_bank_std.cpu(),
        "config": {
            "CATEGORY": CATEGORY, "IMG_SIZE": IMG_SIZE, "BATCH_SIZE": BATCH_SIZE,
            "AE_EPOCHS": AE_EPOCHS, "UNET_EPOCHS": UNET_EPOCHS, "LR": LR,
        },
        "ae_train_losses": ae_train_losses, "ae_val_losses": ae_val_losses,
        "unet_train_losses": unet_train_losses, "unet_val_losses": unet_val_losses,
    }
    torch.save(checkpoint, CHECKPOINT_PATH)
    print(f"\nCheckpoint saved → {CHECKPOINT_PATH}")
    print("Done.  Run  python evaluate.py  for held-out metrics, or  python app.py  for the Gradio demo.")


if __name__ == "__main__":
    main()
