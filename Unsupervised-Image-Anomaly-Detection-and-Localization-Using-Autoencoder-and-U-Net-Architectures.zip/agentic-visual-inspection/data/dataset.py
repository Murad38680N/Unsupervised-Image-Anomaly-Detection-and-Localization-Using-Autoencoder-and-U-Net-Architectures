"""
Dataset classes for MVTec AD:
  - NormalImagesDataset  : defect-free training images (autoencoder)
  - TestDataset          : labeled test images + ground-truth masks
  - RealMaskDataset      : augmented real defect masks (U-Net training)
  - GoodOnlyWrapper      : non-defective test images (AE validation loss)
"""
import os
import glob
import random
from collections import defaultdict

import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset

from config import IMG_SIZE, VAL_FRACTION, SEED


# ── helpers ──────────────────────────────────────────────────────────────────

def load_image(path: str, size: int = IMG_SIZE) -> np.ndarray:
    """Load an image, resize, and return as float32 [0, 1] HWC array."""
    img = Image.open(path).convert("RGB").resize((size, size))
    return np.asarray(img, dtype=np.float32) / 255.0


# ── datasets ─────────────────────────────────────────────────────────────────

class NormalImagesDataset(Dataset):
    """Defect-free training images used to train the autoencoder."""

    def __init__(self, root: str):
        self.paths = sorted(glob.glob(os.path.join(root, "train", "good", "*.*")))
        if not self.paths:
            raise FileNotFoundError(f"No training images in {root}/train/good")

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        return torch.from_numpy(load_image(self.paths[idx])).permute(2, 0, 1)


class TestDataset(Dataset):
    """All labeled test images (good + each defect type) with ground-truth masks."""

    def __init__(self, root: str):
        self.samples = []  # list of (image_path, mask_path_or_None, label)
        for defect_dir in sorted(glob.glob(os.path.join(root, "test", "*"))):
            defect_type = os.path.basename(defect_dir)
            for p in sorted(glob.glob(os.path.join(defect_dir, "*.*"))):
                if defect_type == "good":
                    self.samples.append((p, None, 0))
                else:
                    fname = os.path.splitext(os.path.basename(p))[0]
                    mask_path = os.path.join(
                        root, "ground_truth", defect_type, f"{fname}_mask.png"
                    )
                    self.samples.append(
                        (p, mask_path if os.path.exists(mask_path) else None, 1)
                    )

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, mask_path, label = self.samples[idx]
        img = load_image(path)
        if mask_path is not None:
            mask = (
                np.asarray(
                    Image.open(mask_path).convert("L").resize((IMG_SIZE, IMG_SIZE)),
                    dtype=np.float32,
                )
                / 255.0
            )
        else:
            mask = np.zeros((IMG_SIZE, IMG_SIZE), dtype=np.float32)
        return (
            torch.from_numpy(img).permute(2, 0, 1),
            torch.from_numpy(mask).unsqueeze(0),
            label,
            path,
        )


class RealMaskDataset(Dataset):
    """Real MVTec ground-truth masks from the validation slice only, with
    flip/rotation augmentation.  U-Net trains exclusively on these: real
    abnormal images paired with their real (0/1) ground-truth masks."""

    def __init__(self, base_test_ds, indices, augment=True, repeats=8):
        self.base = base_test_ds
        self.indices = [
            i
            for i in indices
            if base_test_ds.samples[i][2] == 1
            and base_test_ds.samples[i][1] is not None
        ]
        if not self.indices:
            raise ValueError("No labeled defect masks in the validation slice.")
        self.augment = augment
        self.repeats = repeats if augment else 1

    def __len__(self):
        return len(self.indices) * self.repeats

    def __getitem__(self, idx):
        real_idx = self.indices[idx % len(self.indices)]
        img_t, mask_t, label, path = self.base[real_idx]
        img = img_t.permute(1, 2, 0).numpy()
        mask = mask_t.squeeze(0).numpy()
        if self.augment:
            k = random.randint(0, 3)
            img = np.rot90(img, k).copy()
            mask = np.rot90(mask, k).copy()
            if random.random() < 0.5:
                img = np.fliplr(img).copy()
                mask = np.fliplr(mask).copy()
        return (
            torch.from_numpy(img.copy()).permute(2, 0, 1).float(),
            torch.from_numpy(mask.copy()).unsqueeze(0).float(),
        )


class GoodOnlyWrapper(Dataset):
    """Wraps the labeled 'good' test images in a slice for AE validation loss."""

    def __init__(self, test_ds, indices):
        self.base = test_ds
        self.indices = [i for i in indices if test_ds.samples[i][2] == 0]

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        img_t, mask_t, label, path = self.base[self.indices[idx]]
        return img_t


# ── split ────────────────────────────────────────────────────────────────────

def split_test_samples(test_ds, val_frac=VAL_FRACTION, seed=SEED):
    """Stratified split of test indices → (val_indices, final_indices)."""
    rng = random.Random(seed)
    groups = defaultdict(list)
    for i, (path, mask_path, label) in enumerate(test_ds.samples):
        defect_type = os.path.basename(os.path.dirname(path))
        groups[(label, defect_type)].append(i)
    val_idx, final_idx = [], []
    for key, idxs in groups.items():
        idxs = idxs[:]
        rng.shuffle(idxs)
        n_val = max(1, int(round(len(idxs) * val_frac)))
        val_idx.extend(idxs[:n_val])
        final_idx.extend(idxs[n_val:])
    return val_idx, final_idx
