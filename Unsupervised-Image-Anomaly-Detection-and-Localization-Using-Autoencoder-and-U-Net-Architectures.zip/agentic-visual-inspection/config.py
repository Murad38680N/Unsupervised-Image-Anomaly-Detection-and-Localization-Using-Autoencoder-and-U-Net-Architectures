"""
Global configuration for the Agentic Visual Inspection pipeline.
Adjust these before training on a different MVTec AD category.
"""
import os
import glob

# ── Dataset ──────────────────────────────────────────────────────────────────
CATEGORY = "wood"
IMG_SIZE = 128
BATCH_SIZE = 32
VAL_FRACTION = 0.5  # half of each labeled group → validation, half → held-out test

# ── Training ─────────────────────────────────────────────────────────────────
AE_EPOCHS = 40
UNET_EPOCHS = 60
LR = 1e-3
SEED = 42

# ── Paths ────────────────────────────────────────────────────────────────────
CHECKPOINT_PATH = os.path.join("outputs", "agentic_vision_checkpoint.pt")
REPORT_CSV_PATH = os.path.join("outputs", "agent_quantitative_report.csv")


def find_category_root(category: str = CATEGORY) -> str:
    """Locate the MVTec AD category folder under /kaggle/input (Kaggle)
    or a local 'data/' directory."""
    search_roots = ["/kaggle/input", "data"]
    for root in search_roots:
        candidates = glob.glob(
            os.path.join(root, "**", category, "train", "good"), recursive=True
        )
        if candidates:
            # two levels up from .../train/good → category root
            return os.path.dirname(os.path.dirname(candidates[0]))
    raise FileNotFoundError(
        f"Could not find '{category}/train/good' under any of {search_roots}. "
        "Make sure you added the MVTec AD dataset."
    )
