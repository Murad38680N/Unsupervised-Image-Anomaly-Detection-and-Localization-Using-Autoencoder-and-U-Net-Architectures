"""
Evaluation metrics: threshold selection, pixel-level metrics,
dataset-level scoring helpers.
"""
import os
import numpy as np
import torch
from torch.utils.data import DataLoader

from config import BATCH_SIZE


def find_best_threshold(scores, labels):
    """Return the threshold maximising Youden's J = TPR − FPR."""
    candidates = np.unique(scores)
    n_pos = int((labels == 1).sum())
    n_neg = int((labels == 0).sum())
    best_j, best_t = -1.0, float(candidates[0])
    for t in candidates:
        preds = (scores > t).astype(int)
        tp = int(((preds == 1) & (labels == 1)).sum())
        fp = int(((preds == 1) & (labels == 0)).sum())
        tpr = tp / (n_pos + 1e-9)
        fpr = fp / (n_neg + 1e-9)
        j = tpr - fpr
        if j > best_j:
            best_j, best_t = j, float(t)
    return best_t, best_j


def pixel_metrics(pred_mask, gt_mask, thresh=0.5):
    """Per-image pixel-level precision / recall / F1 / IoU / Dice."""
    pred = (pred_mask > thresh).astype(np.float32)
    tp = float((pred * gt_mask).sum())
    fp = float((pred * (1 - gt_mask)).sum())
    fn = float(((1 - pred) * gt_mask).sum())
    precision = tp / (tp + fp + 1e-9)
    recall = tp / (tp + fn + 1e-9)
    f1 = 2 * precision * recall / (precision + recall + 1e-9)
    union = pred.sum() + gt_mask.sum() - tp
    iou = (tp + 1e-9) / (union + 1e-9)
    dice = (2 * tp + 1e-9) / (pred.sum() + gt_mask.sum() + 1e-9)
    return {"precision": precision, "recall": recall, "f1": f1, "iou": iou, "dice": dice}


def collect_pixel_labels(dataset, model, device, threshold=0.5):
    """Flatten every pixel into (ground_truth, predicted) arrays."""
    model.eval()
    all_true, all_pred = [], []
    with torch.no_grad():
        for img_t, mask_t, label, path in DataLoader(dataset, batch_size=1):
            img_t = img_t.to(device)
            pred = model(img_t)
            pred_bin = (pred.squeeze().cpu().numpy() > threshold).astype(int).ravel()
            gt_bin = (mask_t.squeeze().numpy() > 0.5).astype(int).ravel()
            all_pred.append(pred_bin)
            all_true.append(gt_bin)
    return np.concatenate(all_true), np.concatenate(all_pred)


def collect_pixel_scores(dataset, model, device):
    """Flatten every pixel's raw sigmoid probability (for ROC / AUROC)."""
    model.eval()
    all_true, all_scores = [], []
    with torch.no_grad():
        for img_t, mask_t, label, path in DataLoader(dataset, batch_size=1):
            img_t = img_t.to(device)
            pred = model(img_t)
            prob = pred.squeeze().cpu().numpy().ravel()
            gt_bin = (mask_t.squeeze().numpy() > 0.5).astype(int).ravel()
            all_scores.append(prob)
            all_true.append(gt_bin)
    return np.concatenate(all_true), np.concatenate(all_scores)


def score_dataset_ae(dataset, autoencoder, combined_score_fn, device):
    """Score every image in a dataset with the combined AE score."""
    scores, labels = [], []
    with torch.no_grad():
        for imgs, masks, lbls, paths in DataLoader(dataset, batch_size=BATCH_SIZE):
            imgs = imgs.to(device)
            recon = autoencoder(imgs)
            s = combined_score_fn(imgs, recon)
            scores.extend(s.cpu().numpy().tolist())
            labels.extend(lbls.numpy().tolist())
    return np.array(scores), np.array(labels)
