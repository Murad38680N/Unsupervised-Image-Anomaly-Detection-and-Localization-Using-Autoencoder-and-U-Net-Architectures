"""Plotting helpers: confusion matrix, ROC curve, figure → numpy array."""
import io
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt


def plot_confusion(cm, title, labels=("normal", "defect")):
    fig, ax = plt.subplots(figsize=(4, 4))
    im = ax.imshow(cm, cmap="Blues")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(
                j, i, str(cm[i, j]), ha="center", va="center",
                color="white" if cm[i, j] > cm.max() / 2 else "black",
            )
    ax.set_xticks([0, 1]); ax.set_xticklabels(labels)
    ax.set_yticks([0, 1]); ax.set_yticklabels(labels)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(title)
    fig.colorbar(im, ax=ax, fraction=0.046)
    plt.show()


def plot_roc(fpr, tpr, roc_auc, title):
    plt.figure(figsize=(4.5, 4.5))
    plt.plot(fpr, tpr, label=f"AUROC = {roc_auc:.3f}", color="#5EE6B0")
    plt.plot([0, 1], [0, 1], "--", color="gray")
    plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
    plt.title(title); plt.legend()
    plt.show()


def render_fig_to_array(fig) -> np.ndarray:
    """Render a matplotlib figure to an RGB numpy array."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", dpi=110)
    plt.close(fig)
    buf.seek(0)
    return np.array(Image.open(buf).convert("RGB"))
