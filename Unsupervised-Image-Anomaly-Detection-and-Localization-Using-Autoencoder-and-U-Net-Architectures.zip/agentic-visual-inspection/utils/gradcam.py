"""
Grad-CAM adapted for U-Net segmentation.

Hooks a shallow decoder layer (dec2, 64×64) instead of the deepest bottleneck
(8×8) — upsampling from 8×8 produces only smooth, blobby maps.  The gradient
target is the sum of predicted probability over the flagged (> 0.5) region,
not the whole image, anchoring the explanation to the actual defect prediction.
"""
import torch
import torch.nn.functional as F


def compute_gradcam_unet(unet_model, x):
    activations, gradients = {}, {}

    def fwd_hook(module, inp, out):
        activations["value"] = out

    def bwd_hook(module, grad_in, grad_out):
        gradients["value"] = grad_out[0]

    target_layer = unet_model.dec2  # 64×64 spatial
    h1 = target_layer.register_forward_hook(fwd_hook)
    h2 = target_layer.register_full_backward_hook(bwd_hook)

    unet_model.zero_grad()
    x_in = x.clone()
    pred = unet_model(x_in)
    flagged_region = (pred.detach() > 0.5).float()
    target = (
        (pred * flagged_region).sum()
        if flagged_region.sum() > 0
        else pred.sum()
    )
    target.backward()

    acts = activations["value"]
    grads = gradients["value"]
    weights = grads.mean(dim=(2, 3), keepdim=True)
    cam = F.relu((weights * acts).sum(dim=1, keepdim=True))
    cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)
    cam = cam.squeeze().detach().cpu().numpy()
    cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)

    h1.remove()
    h2.remove()
    return cam
