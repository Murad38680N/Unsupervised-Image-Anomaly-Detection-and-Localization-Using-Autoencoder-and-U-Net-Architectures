"""
Anomaly scoring: pixel-space, feature-space, and feature-bank distance,
combined into a single z-normalised score.
"""
import torch
import torch.nn.functional as F

from models.feature_extractor import extract_features


# ── elementary scores ────────────────────────────────────────────────────────

def local_anomaly_score(error_map: torch.Tensor, pool_size: int = 8) -> torch.Tensor:
    pooled = F.avg_pool2d(error_map, kernel_size=pool_size, stride=max(1, pool_size // 2))
    return pooled.amax(dim=(1, 2, 3))


def local_anomaly_score_parts(imgs, recon, extractor, device, pool_size=8):
    """Returns (pixel_score, feature_score) per image in the batch."""
    pixel_err = (recon - imgs).abs().mean(dim=1, keepdim=True)
    pixel_score = local_anomaly_score(pixel_err, pool_size=pool_size)

    feat_imgs = extract_features(imgs, extractor, device)
    feat_recon = extract_features(recon, extractor, device)
    feat_err = (feat_imgs - feat_recon).pow(2).mean(dim=1, keepdim=True)
    feat_err_up = F.interpolate(
        feat_err, size=imgs.shape[-2:], mode="bilinear", align_corners=False
    )
    feat_score = local_anomaly_score(feat_err_up, pool_size=pool_size)
    return pixel_score, feat_score


def feature_bank_score(imgs, extractor, device, feat_bank_mean, feat_bank_std, pool_size=8):
    """Per-location distance from the normal feature distribution."""
    feats = extract_features(imgs, extractor, device)
    z = (feats - feat_bank_mean.unsqueeze(0)) / feat_bank_std.unsqueeze(0)
    dist_map = (z ** 2).mean(dim=1, keepdim=True)
    dist_map_up = F.interpolate(
        dist_map, size=imgs.shape[-2:], mode="bilinear", align_corners=False
    )
    return local_anomaly_score(dist_map_up, pool_size=pool_size)


# ── feature bank construction ────────────────────────────────────────────────

def build_feature_bank(train_loader, extractor, device):
    """Compute per-channel mean and std of features across normal training images."""
    print("Building normal feature bank from training images...")
    extractor.eval()
    feat_sum, feat_sq_sum, n_seen = None, None, 0
    with torch.no_grad():
        for imgs in train_loader:
            imgs = imgs.to(device)
            feats = extract_features(imgs, extractor, device)
            if feat_sum is None:
                feat_sum = feats.sum(dim=0)
                feat_sq_sum = (feats ** 2).sum(dim=0)
            else:
                feat_sum += feats.sum(dim=0)
                feat_sq_sum += (feats ** 2).sum(dim=0)
            n_seen += feats.shape[0]

    mean = feat_sum / n_seen
    var = (feat_sq_sum / n_seen) - mean ** 2
    std = torch.sqrt(var.clamp(min=1e-6))
    print(f"Feature bank built from {n_seen} normal training images.")
    return mean, std


# ── z-normalisation calibration ──────────────────────────────────────────────

def calibrate_normalization(ae_val_loader, autoencoder, extractor, device, feat_bank_mean, feat_bank_std):
    """Calibrate z-score stats from normal-only validation images."""
    import numpy as np

    autoencoder.eval()
    pixel_vals, feat_vals, bank_vals = [], [], []
    with torch.no_grad():
        for imgs in ae_val_loader:
            imgs = imgs.to(device)
            recon = autoencoder(imgs)
            p_s, f_s = local_anomaly_score_parts(imgs, recon, extractor, device)
            b_s = feature_bank_score(imgs, extractor, device, feat_bank_mean, feat_bank_std)
            pixel_vals.extend(p_s.cpu().numpy().tolist())
            feat_vals.extend(f_s.cpu().numpy().tolist())
            bank_vals.extend(b_s.cpu().numpy().tolist())

    stats = {
        "mu_pixel": float(np.mean(pixel_vals)),
        "sigma_pixel": float(np.std(pixel_vals) + 1e-8),
        "mu_feat": float(np.mean(feat_vals)),
        "sigma_feat": float(np.std(feat_vals) + 1e-8),
        "mu_bank": float(np.mean(bank_vals)),
        "sigma_bank": float(np.std(bank_vals) + 1e-8),
    }
    for k, v in stats.items():
        print(f"  {k}: {v:.5f}")
    return stats


# ── combined score ───────────────────────────────────────────────────────────

def combined_anomaly_score(imgs, recon, extractor, device, feat_bank_mean, feat_bank_std, norm_stats):
    """Weighted z-normalised combination of pixel, feature, and bank scores."""
    p_s, f_s = local_anomaly_score_parts(imgs, recon, extractor, device)
    b_s = feature_bank_score(imgs, extractor, device, feat_bank_mean, feat_bank_std)
    z_pixel = (p_s - norm_stats["mu_pixel"]) / norm_stats["sigma_pixel"]
    z_feat = (f_s - norm_stats["mu_feat"]) / norm_stats["sigma_feat"]
    z_bank = (b_s - norm_stats["mu_bank"]) / norm_stats["sigma_bank"]
    return 0.3 * z_pixel + 0.3 * z_feat + 1.4 * z_bank
